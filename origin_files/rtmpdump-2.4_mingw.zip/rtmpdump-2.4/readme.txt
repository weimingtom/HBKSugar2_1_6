make SYS=mingw SHARED=
